Informacion servidor

Mal equipo