--Editar la ruta donde se quiera establecer el tablespace
create tablespace ivre
    owner postgres 
    location 'C:\Users\chave\Documents\TableSpace';