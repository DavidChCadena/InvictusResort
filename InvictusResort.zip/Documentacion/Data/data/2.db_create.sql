create database invictus_resort_database
    with
    tablespace = ivre
    owner = postgres
    encoding = 'UTF8'
    connection limit = -1;